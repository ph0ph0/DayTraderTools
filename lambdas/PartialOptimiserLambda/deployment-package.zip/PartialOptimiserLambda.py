import requests
import json
from functools import reduce
from itertools import product
import numpy as np
import PartialsCalculator as pc

# AtR: List[float], Probability_AtR: List[float]) -> List[Tuple]
# def main(event, context):
def PartialOptimiser(AtR, Probability_AtR, total_shares):
    AtR = event["R"]
    Probability_AtR = event["P_AtR"]
    total_shares = event["total_shares"]
    partials_perc_list = list(product(range(0, 101), repeat=len(AtR)))
    results_array = []

    for partial_tuple in partials_perc_list:
        # ----Optimise for speed
        # If there is not a closing partial, then profit is left on the table
        if 100 not in partial_tuple:
            continue
        # If there are more than one 100% partial, it's meaningless.
        if partial_tuple.count(100) > 1:
            continue
        # If there are partials after a 100% partial, it's meaningless.
        if 100 in partial_tuple:
            i = partial_tuple.index(100)
            end = partial_tuple[i + 1 :]
            if sum(list(end)) != 0:
                continue

        cumsum = pc.Caclulate_CumSum_Profit(partial_tuple, AtR, total_shares)
        total = pc.Total_R(Probability_AtR, cumsum, total_shares)
        results_array.append((partial_tuple, total))

    sorted_array = sorted(results_array, key=lambda x: x[1], reverse=True)

    responseBody = {
        results: sorted_array[:20],
        calculations: len(results_array)
    }

    response = {
        "statusCode": 200,
        "headers": {"my_header": "my_value"},
        "body": json.dumps(responseBody),
        "isBase64Encoded": False,
    }
    return response


# partials = [20, 50, 20, 100]
# at_R = [2, 4, 6, 8]
# Probability_AtR = [80, 57, 40, 10]
# total_shares = 1000

# x = PartialOptimiser(at_R, Probability_AtR, total_shares)
# print(x[:20])


if __name__ == "__main__":
    main("", "")
